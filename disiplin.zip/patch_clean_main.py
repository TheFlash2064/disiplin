with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

start = content.find("super.onCreate(savedInstanceState)")
end = content.find("if (Build.VERSION.SDK_INT >= Build.VERSION.CODES.TIRAMISU)")

clean_content = content[:start] + "super.onCreate(savedInstanceState)\n        " + content[end:]

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(clean_content)
