package com.example

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.Alignment
import android.util.Log
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.TaskRepository
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.ProphetDuasScreen

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var repository: TaskRepository
    private lateinit var moduleRepository: com.example.data.ModuleRepository
    private lateinit var viewModel: TaskViewModel
    private lateinit var moduleViewModel: ModuleViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
        
        enableEdgeToEdge()
        
                try {
            database = Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java, "discipline-db"
            ).fallbackToDestructiveMigration().build()
            Log.d("MainActivity", "Database initialized")
            
            repository = TaskRepository(database.taskDao())
            moduleRepository = com.example.data.ModuleRepository(database.moduleDao())
            Log.d("MainActivity", "Repositories initialized")
            
            val factory = TaskViewModelFactory(repository)
            viewModel = ViewModelProvider(this, factory)[TaskViewModel::class.java]
            Log.d("MainActivity", "TaskViewModel initialized")
            
            val moduleFactory = ModuleViewModelFactory(moduleRepository, repository)
            moduleViewModel = ViewModelProvider(this, moduleFactory)[ModuleViewModel::class.java]
            Log.d("MainActivity", "ModuleViewModel initialized")
        } catch (e: Exception) {
            Log.e("MainActivity", "Error during initialization", e)
            throw e
        }
        
        setContent {
            val isReady by viewModel.isReady.collectAsState()
            
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (!isReady) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        val navController = rememberNavController()
                        NavHost(navController = navController, startDestination = "home") {
                            composable("home") {
                                HomeScreen(viewModel = viewModel, moduleViewModel = moduleViewModel, navController = navController)
                            }
                            composable("prophet_duas") {
                                ProphetDuasScreen(navController = navController)
                            }
                            composable("planner") {
                                com.example.ui.screens.PlannerScreen(viewModel = moduleViewModel, navController = navController)
                            }
                            composable("profile") {
                                com.example.ui.screens.ProfileScreen(viewModel = moduleViewModel, navController = navController)
                            }
                        }
                    }
                }
            }
        }
    }
}
