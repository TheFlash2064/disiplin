package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryDark = Color(0xFFFFFFFF)
val BackgroundDark = Color(0xFF050505)
val SurfaceDark = Color(0x6618181B) // zinc-900/40
val SurfaceVariantDark = Color(0xFF18181B) // zinc-900
val BorderDark = Color(0x0DFFFFFF) // white/5
val OnSurfaceDark = Color(0xFFFFFFFF)
val TextMutedDark = Color(0xFFA1A1AA) // zinc-400

val PrimaryLight = Color(0xFF000000)
val BackgroundLight = Color(0xFFFAFAFA)
val SurfaceLight = Color(0xFFF4F4F5)
val SurfaceVariantLight = Color(0xFFE4E4E7)
val BorderLight = Color(0x0D000000)
val OnSurfaceLight = Color(0xFF000000)
val TextMutedLight = Color(0xFF52525B)

val AccentBlue = Color(0xFF0A84FF)
val AccentGreen = Color(0xFF30D158)
val AccentRed = Color(0xFFFF453A)
val AccentOrange = Color(0xFFFF9F0A)
val GlassmorphismColorDark = Color(0x20FFFFFF)
val GlassmorphismColorLight = Color(0x60FFFFFF)
