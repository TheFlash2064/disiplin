import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

logging_imports = "import android.util.Log\n"
content = content.replace("import android.Manifest", logging_imports + "import android.Manifest")

init_block = """        try {
            database = Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java, "discipline-db"
            ).fallbackToDestructiveMigration().build()
            Log.d("MainActivity", "Database initialized")
            
            repository = TaskRepository(database.taskDao())
            moduleRepository = com.example.data.ModuleRepository(database.moduleDao())
            Log.d("MainActivity", "Repositories initialized")
            
            val factory = TaskViewModelFactory(repository)
            viewModel = ViewModelProvider(this, factory)[TaskViewModel::class.java]
            Log.d("MainActivity", "TaskViewModel initialized")
            
            val moduleFactory = ModuleViewModelFactory(moduleRepository, repository)
            moduleViewModel = ViewModelProvider(this, moduleFactory)[ModuleViewModel::class.java]
            Log.d("MainActivity", "ModuleViewModel initialized")
        } catch (e: Exception) {
            Log.e("MainActivity", "Error during initialization", e)
            throw e
        }"""

content = re.sub(
    r'database = Room.databaseBuilder\([\s\S]*?moduleViewModel = ViewModelProvider\(this, moduleFactory\)\[ModuleViewModel::class.java\]',
    init_block,
    content
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
