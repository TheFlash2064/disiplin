with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if line.strip() == "}":
        if "Spacer(modifier = Modifier.height(16.dp))" in lines[i-2]:
            if "// Task List" in lines[i+2]:
                lines[i] = "        }\n    }\n"
                break

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.writelines(lines)
