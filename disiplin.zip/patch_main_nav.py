with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

import re

# Remove unused routes
content = re.sub(r'composable\("trading"\) \{[\s\S]*?\}\n', '', content)
content = re.sub(r'composable\("sports"\) \{[\s\S]*?\}\n', '', content)
content = re.sub(r'composable\("quran"\) \{[\s\S]*?\}\n', '', content)
content = re.sub(r'composable\("islamic_content"\) \{[\s\S]*?\}\n', '', content)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
