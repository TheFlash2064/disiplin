with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

target = """                val finalLog = newLog.copy(date = viewModel.currentDate.value)
                viewModel.saveTaskLog(finalLog)
                showTaskActionSheet = false
                activeTaskWithLog = null
                NotificationHelper.cancelNotification(context, activeTaskWithLog!!.task)"""

replacement = """                val finalLog = newLog.copy(date = viewModel.currentDate.value)
                viewModel.saveTaskLog(finalLog)
                val task = activeTaskWithLog?.task
                showTaskActionSheet = false
                activeTaskWithLog = null
                if (task != null) {
                    NotificationHelper.cancelNotification(context, task)
                }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
