with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

target = """                    TaskItem(
                        taskWithLog = taskWithLog,
                        onToggle = { isCompleted ->
                            viewModel.toggleTask(taskWithLog, isCompleted)
                            if (isCompleted) {
                                NotificationHelper.cancelNotification(context, taskWithLog.task)
                            } else {
                                NotificationHelper.scheduleNotification(context, taskWithLog.task)
                            }
                        },
                        onEdit = {
                            taskToEdit = taskWithLog.task
                            showAddTaskSheet = true
                        },
                        onDelete = {
                            viewModel.deleteTask(taskWithLog.task)
                            NotificationHelper.cancelNotification(context, taskWithLog.task)
                        }
                    )"""

replacement = """                    TaskItem(
                        taskWithLog = taskWithLog,
                        onToggle = { isCompleted ->
                            viewModel.toggleTask(taskWithLog, isCompleted)
                            if (isCompleted) {
                                NotificationHelper.cancelNotification(context, taskWithLog.task)
                            } else {
                                NotificationHelper.scheduleNotification(context, taskWithLog.task)
                            }
                        },
                        onClick = {
                            activeTaskWithLog = taskWithLog
                            showTaskActionSheet = true
                        },
                        onEdit = {
                            taskToEdit = taskWithLog.task
                            showAddTaskSheet = true
                        },
                        onDelete = {
                            viewModel.deleteTask(taskWithLog.task)
                            NotificationHelper.cancelNotification(context, taskWithLog.task)
                        }
                    )"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
