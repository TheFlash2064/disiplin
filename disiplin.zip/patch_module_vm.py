with open('app/src/main/java/com/example/ModuleViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace(
"""    private suspend fun updateXP(xpChange: Int) {
        val current = taskRepository.userStats.stateIn(viewModelScope, SharingStarted.Lazily, UserStats()).value""",
"""    private suspend fun updateXP(xpChange: Int) {
        val current = userStats.value"""
)

with open('app/src/main/java/com/example/ModuleViewModel.kt', 'w') as f:
    f.write(content)
