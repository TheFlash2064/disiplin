import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

crash_logger_code = """
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val logFile = java.io.File(applicationContext.filesDir, "crash_log.txt")
                logFile.appendText("Crash in ${thread.name}:\n")
                logFile.appendText(android.util.Log.getStackTraceString(throwable))
                logFile.appendText("\n\n")
            } catch (e: Exception) {
                // Ignore
            }
            // Let the app crash normally
            kotlin.system.exitProcess(1)
        }
"""

# Insert right after super.onCreate(savedInstanceState)
content = content.replace("super.onCreate(savedInstanceState)", "super.onCreate(savedInstanceState)\n" + crash_logger_code)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
