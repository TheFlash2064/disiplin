with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

target = """                NavigationBarItem(
                    icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "Dualar") },
                    label = { Text("Dualar") },
                    selected = false,
                    onClick = { navController.navigate("prophet_duas") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.onBackground,
                        selectedIconColor = MaterialTheme.colorScheme.background,
                        selectedTextColor = MaterialTheme.colorScheme.onBackground
                    )
                )"""

replacement = """                NavigationBarItem(
                    icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "Dualar") },
                    label = { Text("Dualar") },
                    selected = false,
                    onClick = { navController.navigate("prophet_duas") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.onBackground,
                        selectedIconColor = MaterialTheme.colorScheme.background,
                        selectedTextColor = MaterialTheme.colorScheme.onBackground
                    )
                )
                NavigationBarItem(
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.DateRange, contentDescription = "Planlayıcı") },
                    label = { Text("Planlayıcı") },
                    selected = false,
                    onClick = { navController.navigate("planner") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.onBackground,
                        selectedIconColor = MaterialTheme.colorScheme.background,
                        selectedTextColor = MaterialTheme.colorScheme.onBackground
                    )
                )
                NavigationBarItem(
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Person, contentDescription = "Profil") },
                    label = { Text("Profil") },
                    selected = false,
                    onClick = { navController.navigate("profile") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.onBackground,
                        selectedIconColor = MaterialTheme.colorScheme.background,
                        selectedTextColor = MaterialTheme.colorScheme.onBackground
                    )
                )"""

content = content.replace(target, replacement)

# Need to import Person and DateRange icons
content = content.replace("import androidx.compose.material.icons.filled.Edit", 
"import androidx.compose.material.icons.filled.Edit\nimport androidx.compose.material.icons.filled.Person\nimport androidx.compose.material.icons.filled.DateRange")

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
