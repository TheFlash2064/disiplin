with open('app/src/main/java/com/example/data/Models.kt', 'r') as f:
    content = f.read()

content = content.replace("enum class TaskType {\n    CHECKBOX, DURATION, COUNT\n}", 
"enum class TaskType {\n    CHECKBOX, DURATION, COUNT, SPORTS, TRADING, QURAN, VIDEO, PRAYER\n}")

content = content.replace("val progress: Int = 0\n)", 
"val progress: Int = 0,\n    val notes: String? = null,\n    val extraData1: String? = null,\n    val extraData2: String? = null,\n    val extraData3: String? = null\n)")

with open('app/src/main/java/com/example/data/Models.kt', 'w') as f:
    f.write(content)
