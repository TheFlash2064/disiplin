import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# Replace Color(task.color) with Color(task.color.toULong()) or Color(task.color.toULong().toLong()) - wait, Color(Long) is the internal encoding. We should use Color(task.color.toInt()) if it's ARGB.
# Let's use Color((task.color and 0xFFFFFFFF).toInt()) to be safe, or just Color(task.color.toInt())
content = content.replace("Color(task.color)", "Color(task.color.toULong())")

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
