with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
"""        val backgroundColor by animateColorAsState(
            targetValue = MaterialTheme.colorScheme.surface,
            animationSpec = tween(300),
            label = "backgroundColor"
        )""",
"""        val backgroundColor by animateColorAsState(
            targetValue = if (isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
            animationSpec = tween(300),
            label = "backgroundColor"
        )"""
)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
