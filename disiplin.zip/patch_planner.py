with open('app/src/main/java/com/example/ui/screens/PlannerScreen.kt', 'r') as f:
    content = f.read()

target = """            val times = listOf(
                "08:00" to "Sabah Namazı",
                "09:00" to "Spor",
                "13:00" to "Backtesting",
                "20:00" to "Kur'an",
                "22:00" to "Gün Sonu Değerlendirmesi"
            )
            
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(times) { (time, task) ->
                    var isCompleted by remember { mutableStateOf(false) }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isCompleted) AccentGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface)
                            .clickable { isCompleted = !isCompleted }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(time, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (isCompleted) AccentGreen else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(60.dp))
                        Text(task, fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
                    }
                }
            }"""

replacement = """            val events by viewModel.plannerEvents.collectAsState()
            
            var showAddEvent by remember { mutableStateOf(false) }
            
            Button(
                onClick = { showAddEvent = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Yeni Plan Ekle")
            }
            
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(events.sortedBy { it.time }) { event ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (event.isCompleted) AccentGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface)
                            .clickable { viewModel.togglePlannerEvent(event, !event.isCompleted) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(event.time, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (event.isCompleted) AccentGreen else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(60.dp))
                            Text(event.title, fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
                        }
                        IconButton(onClick = { viewModel.deletePlannerEvent(event) }) {
                            Icon(androidx.compose.material.icons.Icons.Default.Delete, contentDescription = "Sil", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            
            if (showAddEvent) {
                var newTime by remember { mutableStateOf("08:00") }
                var newTitle by remember { mutableStateOf("") }
                
                AlertDialog(
                    onDismissRequest = { showAddEvent = false },
                    title = { Text("Yeni Plan Ekle") },
                    text = {
                        Column {
                            OutlinedTextField(
                                value = newTime,
                                onValueChange = { newTime = it },
                                label = { Text("Saat (Örn: 08:00)") }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newTitle,
                                onValueChange = { newTitle = it },
                                label = { Text("Plan/Görev Adı") }
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (newTime.isNotBlank() && newTitle.isNotBlank()) {
                                viewModel.addPlannerEvent(com.example.data.PlannerEvent(time = newTime, title = newTitle))
                                showAddEvent = false
                            }
                        }) {
                            Text("Ekle")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showAddEvent = false }) {
                            Text("İptal")
                        }
                    }
                )
            }"""

content = content.replace(target, replacement)
content = content.replace("import androidx.compose.material.icons.automirrored.filled.ArrowBack", 
"import androidx.compose.material.icons.automirrored.filled.ArrowBack\nimport androidx.compose.material.icons.filled.Delete")
with open('app/src/main/java/com/example/ui/screens/PlannerScreen.kt', 'w') as f:
    f.write(content)
