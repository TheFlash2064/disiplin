with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

imports = """import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.Alignment
"""

content = content.replace("import android.Manifest", imports + "import android.Manifest")

set_content = """        setContent {
            val isReady by viewModel.isReady.collectAsState()
            
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (!isReady) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        val navController = rememberNavController()
                        NavHost(navController = navController, startDestination = "home") {
                            composable("home") {
                                HomeScreen(viewModel = viewModel, moduleViewModel = moduleViewModel, navController = navController)
                            }
                            composable("prophet_duas") {
                                ProphetDuasScreen(navController = navController)
                            }
                            composable("planner") {
                                com.example.ui.screens.PlannerScreen(viewModel = moduleViewModel, navController = navController)
                            }
                            composable("profile") {
                                com.example.ui.screens.ProfileScreen(viewModel = moduleViewModel, navController = navController)
                            }
                        }
                    }
                }
            }
        }"""

content = content.replace("""        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(viewModel = viewModel, moduleViewModel = moduleViewModel, navController = navController)
                        }
                        composable("prophet_duas") {
                            ProphetDuasScreen(navController = navController)
                        }
                        composable("planner") {
                            com.example.ui.screens.PlannerScreen(viewModel = moduleViewModel, navController = navController)
                        }
                        composable("profile") {
                            com.example.ui.screens.ProfileScreen(viewModel = moduleViewModel, navController = navController)
                        }
                    }
                }
            }
        }""", set_content)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
