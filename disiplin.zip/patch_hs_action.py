with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

state_target = "    var taskToEdit by remember { mutableStateOf<Task?>(null) }"
state_replacement = """    var taskToEdit by remember { mutableStateOf<Task?>(null) }
    var showTaskActionSheet by remember { mutableStateOf(false) }
    var activeTaskWithLog by remember { mutableStateOf<TaskWithLog?>(null) }"""

content = content.replace(state_target, state_replacement)

# Add TaskActionSheet when showTaskActionSheet is true
sheet_target = "    if (showAddTaskSheet) {"
sheet_replacement = """    if (showTaskActionSheet && activeTaskWithLog != null) {
        TaskActionSheet(
            taskWithLog = activeTaskWithLog!!,
            onDismissRequest = { 
                showTaskActionSheet = false
                activeTaskWithLog = null
            },
            onSaveTaskLog = { newLog ->
                val finalLog = newLog.copy(date = viewModel.currentDate.value)
                viewModel.saveTaskLog(finalLog)
                showTaskActionSheet = false
                activeTaskWithLog = null
                NotificationHelper.cancelNotification(context, activeTaskWithLog!!.task)
            }
        )
    }
    
    if (showAddTaskSheet) {"""

content = content.replace(sheet_target, sheet_replacement)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
