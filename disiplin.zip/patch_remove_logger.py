import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# I will just replace the crash logger block with super.onCreate(savedInstanceState)
# Since I used regex, let's just do it manually.
start = content.find("super.onCreate(savedInstanceState)")
if start != -1:
    end = content.find("try {", start)
    if end != -1:
        content = content[:start] + "super.onCreate(savedInstanceState)\n        " + content[end:]

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
