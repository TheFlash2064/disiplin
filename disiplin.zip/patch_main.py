with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace(
"""            database = Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java, "discipline-db"
            ).fallbackToDestructiveMigration(dropAllTables = true).build()""",
"""            try {
                database = Room.databaseBuilder(
                    applicationContext,
                    AppDatabase::class.java, "discipline-db"
                ).fallbackToDestructiveMigration().build()
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Database initialization failed", e)
                throw e
            }"""
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
