import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# Replace `Column(` right after `) { padding ->` with `LazyColumn(`
content = re.sub(
    r'\) \{ padding ->\s+Column\(\s+modifier = Modifier\s+\.fillMaxSize\(\)\s+\.padding\(padding\)\s+\.padding\(horizontal = 24\.dp\)\s+\) \{',
    r') { padding ->\n        LazyColumn(\n            modifier = Modifier\n                .fillMaxSize()\n                .padding(padding)\n                .padding(horizontal = 24.dp),\n            verticalArrangement = Arrangement.spacedBy(12.dp),\n            contentPadding = PaddingValues(bottom = 80.dp)\n        ) {\n            item {\n                Column {',
    content
)

# Replace the inner LazyColumn and close the item Column
content = re.sub(
    r'            Spacer\(modifier = Modifier.height\(24.dp\)\)\n\n            // Task List\n            LazyColumn\(\n                modifier = Modifier.weight\(1f\),\n                verticalArrangement = Arrangement.spacedBy\(12.dp\),\n                contentPadding = PaddingValues\(bottom = 80.dp\) // extra padding for FAB\n            \) \{',
    r'                Spacer(modifier = Modifier.height(24.dp))\n            }\n\n            // Task List',
    content
)

# And now we need to remove the closing bracket of the inner LazyColumn.
# It's right before the closing bracket of the outer Column.
# Wait, actually, let's just make the script smarter.

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
