import re

with open('app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()

permissions = """
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

    <application"""

content = content.replace('<application', permissions)

receiver = """
        <receiver android:name=".NotificationReceiver" android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>
    </application>"""

content = content.replace('</application>', receiver)

with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(content)
